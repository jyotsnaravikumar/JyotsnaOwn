package com.jyotsna.projects.LinkedList;

/**
 * Created by 200021831 on 8/12/17.
 */
public class MyLinkedList {
     Node head;

    public void appendNode(int data){
        Node newNode = new Node(data);
        if(head == null){
            head = newNode;
        }else{
            Node temp = head;
            while(temp.next != null){
                temp = temp.next;
            }
            temp.next = newNode;
        }
   }

    public void prependNode(int data){
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void getNthElementInList(int n){
        //Ex :  Get 5th element from first in the list
        System.out.println();
        int count = 0;
        Node temp = head;
        while(temp != null){
            count++;
            if(count == n) {
                System.out.println("data at " + n + " is "+ temp.data);
            }else{
                temp = temp.next;
            }
        }
    }

    public void getKthElementFromEndOfList(int n){
        //continue from here
        Node firstPtr = head;
        Node secondPtr = head;

        for( int i =0;i<n; i++){
            firstPtr = firstPtr.next;
        }

        while(firstPtr != null){
            secondPtr = secondPtr.next;
            firstPtr = firstPtr.next;
        }

        System.out.println("Kth element from end of linkedlist is "+secondPtr.data);

    }

    public void findMiddleElementOfLinkedList(){
        Node firstPtr = head;
        Node secondPtr = head;

        while(firstPtr != null){
            firstPtr = firstPtr.next;
            if(firstPtr!=null && firstPtr.next!=null){
                firstPtr = firstPtr.next;
                secondPtr = secondPtr.next;
            }
        }
        System.out.println("middle element is " + secondPtr.data);
    }

    public void ifLoopExists(){
        Node fp = head;
        Node sp = head;

        while(fp!=null){
            if(fp!=null &&fp.next!=null){
                fp = fp.next.next;
                sp = sp.next;

                if(fp == sp){
                    System.out.println("cycle exists");
                }
            }
        }
    }

    public Node reverseLinkedList(Node currNode){
        Node previousNode=null;
        Node nextNode;
        while(currNode!=null)
        {
            nextNode=currNode.next;
            currNode.next=previousNode;
            previousNode=currNode;
            currNode=nextNode;
        }
        return previousNode;

    }

    public void traverseList(Node node){
     if(node == null){
         System.out.println("Empty list");
     }
      Node temp = node;
      while(temp != null) {
            System.out.print("->" + temp.data);
            temp = temp.next;
        }
    }

    public static void main(String args[]){
        MyLinkedList list = new MyLinkedList();

        list.head = new Node(1);
        list.head.next = new Node(2);
        list.head.next.next = new Node(3);
        list.head.next.next.next = new Node(4);
        list.head.next.next.next.next = new Node(5);
        list.head.next.next.next.next.next = new Node(6);


        list.appendNode(7);
        list.prependNode(0);
        list.traverseList(list.head);
        list.getNthElementInList(4);
        list.getKthElementFromEndOfList(3);
        list.findMiddleElementOfLinkedList();

        Node reversed = list.reverseLinkedList(list.head);
        System.out.println("reversed head is "+reversed.data);
        list.traverseList(reversed);
    }
}
