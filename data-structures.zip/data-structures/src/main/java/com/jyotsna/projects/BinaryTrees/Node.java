package com.jyotsna.projects.BinaryTrees;

/**
 * Created by 200021831 on 8/11/17.
 */
public class Node {

    int data;
    Node left, right;

    Node(int item){
        this.data = item;
        left=right=null;
    }


}
