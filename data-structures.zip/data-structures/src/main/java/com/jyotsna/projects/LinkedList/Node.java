package com.jyotsna.projects.LinkedList;

/**
 * Created by 200021831 on 8/12/17.
 */
public class Node {
    int data;
    Node next;

    Node(int item){
        data = item;
        next = null;
    }

}
