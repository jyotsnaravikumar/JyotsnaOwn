package com.jyotsna.projects.DynamicProgramming;

/**
 * Created by 200021831 on 7/29/17.
 */
public class Fibonacci {

    public int fibonacci(int n){
        if(n == 0 || n == 1)
            return n;
        else
            return fibonacci(n-1)+fibonacci(n-2);
    }

    public int fibonacci_dynamic(int n){
        //define array to store fib series
        int [] mem = new int[n+1];
        mem[0] = 0;
        mem[1] = 1;

        int i;
        for(i=2; i<= n; i++){
            mem[i] = fibonacci(i-1)+fibonacci(i-2);
        }
        return mem[n];
    }
}
