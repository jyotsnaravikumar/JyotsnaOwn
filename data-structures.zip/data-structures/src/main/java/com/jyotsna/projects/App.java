package com.jyotsna.projects;

import com.jyotsna.projects.Arrays.ArrayManipulations;
import com.jyotsna.projects.DynamicProgramming.Fibonacci;
import com.jyotsna.projects.Strings.StringManipulations;
import com.jyotsna.projects.graphs.DFS;
import com.jyotsna.projects.graphs.DFSStack;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        System.out.println( "Hello World!" );

        System.out.println( "**********************************************" );
        System.out.println( "Depth First Search - Regular" );
        DFS graph = new DFS(4);
        graph.addEdge(0,1);
        graph.addEdge(0,2);
        graph.addEdge(1,2);
        graph.addEdge(2,0);
        graph.addEdge(2,3);
        graph.addEdge(3,3);

        //traverse from node 2
        graph.DFSTraverse(2);

        System.out.println( "**********************************************" );
        System.out.println( "Depth First Search -  Stack" );
        DFSStack stackGraph = new DFSStack(4);
        stackGraph.addEdge(0,1);
        stackGraph.addEdge(0,2);
        stackGraph.addEdge(1,2);
        stackGraph.addEdge(2,0);
        stackGraph.addEdge(2,3);
        stackGraph.addEdge(3,3);

        stackGraph.DFS(2);


        //remove duplicates from array
        System.out.println();
        System.out.println( "**********************************************" );
        System.out.println( "Remove Duplicates" );

        ArrayManipulations am = new ArrayManipulations();
        int [] arr = {1,1,2,2,3,4,4,5,5,5};
        int n = arr.length;
        am.removeDuplicatesWithoutSet(arr, n);
        am.removeDuplicatesWithSet(arr, n);

        //dynamic programming fib series
        System.out.println();
        Fibonacci fib = new Fibonacci();
        int res = fib.fibonacci(6);
        System.out.println("regular fib " + res);

        int res_new = fib.fibonacci_dynamic(6);
        System.out.println("dynamic fib " + res_new);

        //is string a palindrome
        System.out.println();
        StringManipulations sm = new StringManipulations();
        String input = "malayalamq";
        sm.isPalindrome_reverse(input);
        sm.isPalindrome_charComparison(input);

        //string reverse
        System.out.println();
        String str = "malayalamq";
        System.out.println("reverse of " +str + " is " + sm.reverseString(str));

        //is string anagram
        System.out.println();
        String s1 = "margana Anagram";
        String s2 = "anagram Margana";

        sm.isAnagram_bySortCompare(s1, s2);

        //Duplicate words in a sentence
        System.out.println();
        System.out.println( "**********************************************" );
        System.out.println( "Duplicate words" );
        String sentence = "This thing is a kind of a strange thing";
        sm.countDuplicateWordsInString(sentence);





    }
}
