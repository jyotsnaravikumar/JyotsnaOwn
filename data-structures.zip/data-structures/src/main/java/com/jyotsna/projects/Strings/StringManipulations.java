package com.jyotsna.projects.Strings;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Created by 200021831 on 7/29/17.
 */
public class StringManipulations {
    //Palindrome
    public boolean isPalindrome_reverse(String input){
        System.out.println("input is "+input);

        //reverse and compare
        if(input.equals(new StringBuilder(input).reverse().toString())) {
            System.out.println(input + " is a palindrome");
            return true;
        }else{
            System.out.println(input + " not a palindrome");
            return false;
        }
    }

    public void isPalindrome_charComparison(String input) {
        String reverse = reverseString(input);
        System.out.println("reverse is "+ reverse);
        if( input.equals(reverse))
            System.out.println(input + " is a palindrome");
        System.out.println(input + " not a palindrome");


    }

    public String reverseString(String input){
        String reverse = "";
        for(int i = input.length() -1; i >=0  ; i--){
            reverse += input.charAt(i);
        }
        return reverse;
    }

    //Anagrams - performance is 2nlog(n)
    public void isAnagram_bySortCompare(String firstWord, String secondWord){

        // School Master
        // Class room
        if(firstWord == null || secondWord == null || firstWord.length() != secondWord.length()){
            System.out.println("Not a anagram");
        }
        char[] firstArray = firstWord.trim().toLowerCase().toCharArray();
        char[] secondArray = secondWord.trim().toLowerCase().toCharArray();

        Arrays.sort(firstArray);
        Arrays.sort(secondArray);

        if(Arrays.equals(firstArray,secondArray)) {
            System.out.println("Is a Anagram");
        }else{
            System.out.println("Not a Anagram");
        }

    }

    public void isAnagram_HashMap(String firstWord, String secondWord){

        if(firstWord == null || secondWord == null || firstWord.isEmpty() || secondWord.isEmpty())
            System.out.println("IIlegal Arguments");

        if(firstWord.length() != secondWord.length())
            System.out.println("Not Anagrams");

        HashMap<Character, Integer> map = new HashMap<Character, Integer>();

       //Do this tomorrow

        //place 2nd string in hashmap
        for(int i =0; i < secondWord.length() -1; i++){
            char key = secondWord.charAt(i);
            if(map.containsKey(key)){
                int freq = map.get(key);
                map.put(key,freq++);
            }else
                map.put(key,1);
        }

        //compare 1st string with 2nd string in map
        for(int j = 0; j<firstWord.length() -1; j++){

            char key = firstWord.charAt(j);
            if(map.containsKey(key)){
                int freq = map.get(key);
                if(freq == 0){
                    map.remove(map.get(key));
                }else {
                   map.put(key, freq--);
                }
               // return map.isEmpty();
            }else{
                System.out.println("not an anagram");
            }
        }

    }


    public void countDuplicateWordsInString(String input){
        //" This thing is a kind of a strange thing"

        StringTokenizer tokenizer = new StringTokenizer(input);
        System.out.println("No of tokens are "+ tokenizer.countTokens());

        HashMap<String, Integer> wordCount = new HashMap<>();
        while(tokenizer.hasMoreTokens()){
            String key = tokenizer.nextToken();
            if(wordCount.containsKey(key)){
                wordCount.put(key, wordCount.get(key) + 1);
            }else{
                wordCount.put(key, 1);
            }
        }

        for (Map.Entry<String, Integer> entry :wordCount.entrySet()
             ) {
            System.out.println("Key: " + entry.getKey() + " Value: " + entry.getValue());
        }
    }
}
