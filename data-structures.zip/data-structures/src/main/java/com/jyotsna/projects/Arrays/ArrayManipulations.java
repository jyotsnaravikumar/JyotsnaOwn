package com.jyotsna.projects.Arrays;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by 200021831 on 7/28/17.
 */
public class ArrayManipulations {

    public void removeDuplicatesWithoutSet(int arr[], int n) {

        System.out.println();
        System.out.print("input array with duplicates is : ");
        for (int i = 0; i < n; i++) {
            System.out.print(" " + arr[i]);
        }

        //remove the duplicates
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i] == arr[j]) {
                    arr[j] = arr[n - 1];
                    n--;
                    j--;
                }
            }
        }

        int[] nonDupArray = Arrays.copyOf(arr, n);

        System.out.println();
        System.out.print("input array without  duplicates is : ");
        for (int i = 0; i < n; i++) {
            System.out.print(" " + nonDupArray[i]);

        }
    }

    public void removeDuplicatesWithSet(int arr[], int n) {
        System.out.println();
        System.out.print("input array with duplicates is : ");
        for (int i = 0; i < n; i++) {
            System.out.print(" " + arr[i]);
        }

        HashSet<Integer> set = new HashSet<Integer>();
        for(int i =0; i< n; i++){
            set.add(arr[i]);
        }
        System.out.println();
        System.out.print("output array without duplicates is : ");

        Iterator<Integer> i = set.iterator();
        while (i.hasNext()){
            int b = i.next();
            System.out.print(" "+b);
       }
    }

    public void removeDuplicateWithJava8Lamda(int[] arr) {
        List<Integer> arrWithDups = new ArrayList<Integer>();
        for (int i = 0; i < arr.length; i++) {
            arrWithDups.add(arr[i]);
        }

        List<Integer> listWithoutDuplicates = arrWithDups.stream()
                .distinct()
                .collect(Collectors.toList());
    }


}
