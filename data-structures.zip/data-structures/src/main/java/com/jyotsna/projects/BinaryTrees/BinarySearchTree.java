package com.jyotsna.projects.BinaryTrees;

/**
 * Created by 200021831 on 8/13/17.
 */
public class BinarySearchTree {
    Node root;

    public void insert(int data){
        root = insert(root, data);
    }

    public Node insert(Node root, int data){

       if(root == null){
           root = new Node(data);
           return root;
       }
       if(data < root.data){
           root.left = insert(root.left, data);
       }else if ( data > root.data){
           root.right = insert(root.right, data);
       }
       return root;
   }

    public void traverse(){
        inorder_traverse(root);
    }
    public void inorder_traverse(Node root){
       if(root != null){
           inorder_traverse(root.left);
           System.out.print(" "+root.data);
           inorder_traverse(root.right);
       }
    }

    public static void main(String args[]){
        BinarySearchTree bst = new BinarySearchTree();
        bst.insert(50);
        bst.insert(30);
        bst.insert(20);
        bst.insert(40);
        bst.insert(60);
        bst.insert(70);
        bst.insert(80);

        bst.traverse();



    }





}
