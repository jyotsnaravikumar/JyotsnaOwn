package com.jyotsna.projects.graphs;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;
import java.util.Vector;

/**
 * Created by 200021831 on 7/30/17.
 */
public class DFSStack {

    private int V;
    private LinkedList<Integer>[] adj;

    public DFSStack(int V)
    {
        this.V = V;
        adj = new LinkedList[V];

        for (int i = 0; i < adj.length; i++)
            adj[i] = new LinkedList<Integer>();
    }

    public void addEdge(int v, int w)
    {
        adj[v].add(w);
    }

    public void DFS(int s)
    {
        Vector<Boolean> visited = new Vector<Boolean>(V);
        for (int i = 0; i < V; i++)
            visited.add(false);

        Stack<Integer> stack = new Stack<>();
        stack.push(s);
        while(stack.empty() == false)
        {
            s = stack.peek();
            stack.pop();
           if(visited.get(s) == false)
            {
                System.out.print(s + " ");
                visited.set(s, true);
            }
            Iterator<Integer> itr = adj[s].iterator();

            while (itr.hasNext())
            {
                int v = itr.next();
                if(!visited.get(v))
                    stack.push(v);
            }

        }
    }

}
