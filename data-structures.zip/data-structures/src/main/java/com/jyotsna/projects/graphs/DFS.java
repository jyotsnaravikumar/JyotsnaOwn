package com.jyotsna.projects.graphs;

import java.util.Iterator;
import java.util.LinkedList;

/**
 * Created by 200021831 on 7/28/17.
 */
public class DFS {

    //Define
    private int V;
    private LinkedList<Integer> adj[];

    //Construct
    public DFS(int v){
        V = v;
        adj = new LinkedList[v];
        for(int i=0; i<v; ++i){
            adj[i] = new LinkedList();
        }

    }

    //Add Edges
    public void addEdge(int v, int w){
        adj[v].add(w);
    }

    //DFSUtil

    public void DFSUtil(int v, boolean visited[]){
        // Mark the current node as visited and print it
        visited[v] = true;
        System.out.print(v+" ");

        //iterate thru adjacent nodes and if the nodes are not visited
        Iterator<Integer> i = adj[v].listIterator();
        while (i.hasNext()){
            int n = i.next();

            if(!visited[n]){
                DFSUtil(n,visited);
            }
        }
    }

    public void DFSTraverse(int v){
        boolean visited[] = new boolean[V];
        DFSUtil(v,visited);
    }

}
