package com.jyotsna.projects.Files;

import java.io.File;

/**
 * Created by 200021831 on 8/11/17.
 */
public class FindDepthOfFileStructure {

    public static void main(String args[]) {
        String dirPath = "/Users";
        File file = new File(dirPath);
        int depth = depthOfDir(file);
        System.out.println("depth is "+ depth);
        System.out.println("no of files in "+ dirPath + " : " + listFilesUnderDir(file));


    }

    public static int depthOfDir(File dir){
        int depth = 1;

        File file[] = dir.listFiles();
        if(file != null){
        for(int i=0; i<file.length;i++){
            if(file[i].isDirectory()){
                depth++;
            }
        }
        }else{
            System.out.println("No files found");
        }

        return depth;
    }

    public static int listFilesUnderDir(File dir){

        String[] files = dir.list();
        int cnt = 0;
        if(files != null) {

            for (int i = 0; i < files.length; i++) {
                cnt++;
                System.out.println("   " + files[i]);
            }

        }
        return cnt;
    }
}
